// components/hh-addehr.js
Component({
  behaviors: [require('./hhBehaviors.js')],
  /**
   * 组件的属性列表
   */
  properties: {

  },

  /**
   * 组件的初始数据
   */
  data: {
    _name: 'hh-addehr'
  },

  /**
   * 组件的方法列表
   */
  methods: {
    _requestComplete() {}
  }
})